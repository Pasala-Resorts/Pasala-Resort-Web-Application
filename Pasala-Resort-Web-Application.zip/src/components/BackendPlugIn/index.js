import React,{useEffect} from "react";
import { useLocation } from 'react-router-dom';

const BackendPlugIn = () => {
  const location = useLocation();
  const isRenderBP = location?.state?.bookingPage;
  useEffect=(()=>{},[isRenderBP])

  console.log(location);

  return isRenderBP ? <div id="webDiv" style={{ borderWidth: 0, marginTop: '10vh' }}></div> : null;
};

export default BackendPlugIn;
