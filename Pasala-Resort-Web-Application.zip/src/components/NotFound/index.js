import './notfound.css'

const NotFound=()=>{
    return(<div>
        <img className='not-found-image' src="https://res.cloudinary.com/raghu11221/image/upload/v1693925473/error-404-solid-text-magnifying-glass-isolated-white-surface-3d-illustration_bqh3f2.jpg" alt=""/>
    </div>)
}

export default NotFound